package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NimapTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(NimapTaskApplication.class, args);
	}

}
